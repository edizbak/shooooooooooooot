function displayScore(){
	document.getElementById('playerName').style.visibility = "visible";
}