musique = new Audio('assets/SweetDreams.mp3'),
hitSong = new Audio("assets/hit.wav"),
shootSong = new Audio("assets/shoot2.wav"),
bonusSong = new Audio("assets/bonus.mp3"),
loseSong = new Audio("assets/lose.wav"),
deathSong = new Audio("assets/shipdeath.wav"),
startSong = new Audio("assets/start.mp3");

